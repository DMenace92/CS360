package com.example.dennis_enwiya_inventory_finalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "inventoryApp.db";
    private static DBHelper mInventoryDb;

    public enum ItemSortOrder { ALPHABETIC};

    public static DBHelper getInstance(Context context){
        if (mInventoryDb == null){
            return mInventoryDb = new DBHelper(context);
        }else{
            return mInventoryDb;
        }
    }

    public DBHelper( Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }
    private static final class user_table {
        private static final String TABLE = "user";
        private static final String ID = "id";
        private static final String USERNAME = "username";
        private static final String PASSWORD = "password";
        private static final String FIRSTNAME = "firstname";
        private static final String LASTNAME = "lastname";
        private static final String EMAIL = "email";
      //  private static final String NOTIFY = "false" ;
    }
    private static final class item_table{
        private static final String TABLE = "item";
        private static final String ID = "id";
        private static final String ITEM_NAME = "item_name";
        private static final String ITEM_WEIGHT = "item_weight";
        private static final String ITEM_INVENTORY = "item_inventory";
        private static final String ITEM_DESCRIPTION = "item_description";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //sql create statement for user
        db.execSQL("create table " + user_table.TABLE + " (" +
                  user_table.ID + " integer primary key autoincrement, " +
                  user_table.USERNAME + ", " +
                  user_table.PASSWORD+  ", " +
                  user_table.FIRSTNAME + ", " +
                  user_table.LASTNAME+ ", " +
                  user_table.EMAIL + ")" );
                //+ ", " + user_table.NOTIFY);
        //sql create statement for inventory
        db.execSQL("create table " + item_table.TABLE + " (" +
                item_table.ID +" integer primary key autoincrement, " +
                item_table.ITEM_NAME + ", " +
                item_table.ITEM_WEIGHT + ", " +
                item_table.ITEM_INVENTORY + ", " +
                item_table.ITEM_DESCRIPTION + " references "  +
                user_table.TABLE + "("+ item_table.ID + ") on delete cascade)");
//                item_table.ID +" integer primary key autoincrement, " +
//                item_table.ITEM_NAME + ", " +
//                item_table.ITEM_WEIGHT + ", " +
//                item_table.ITEM_INVENTORY + ", " +
//                item_table.ITEM_DESCRIPTION + ")" );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(newVersion>oldVersion) {


            db.execSQL("drop table if exists " + user_table.TABLE);
            db.execSQL("drop table if exists " + item_table.TABLE);
            onCreate(db);
        }
    }



    //___________________create data_____________________
    public boolean insertUserData(String username, String password, String firstname, String lastname, String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username",username);
        values.put("password", password);
        values.put("firstname", firstname);
        values.put("lastname", lastname);
        values.put("email", email);
        long result = db.insert("user", null, values);
        if (result == -1) {
            return false;
        }else{
            return true;
        }
    }
    //refactored using with arrayList
//    public boolean insertItemData(Item item){
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues values = new ContentValues();
//        values.put(item_table.ITEM_NAME, item.getItemName());
//        values.put(item_table.ITEM_WEIGHT, item.getItemWeight());
//        values.put(item_table.ITEM_INVENTORY, item.getItemInventory());
//        values.put(item_table.ITEM_DESCRIPTION, item.getItemDescription());
//        long id = db.insert(item_table.TABLE, null, values);
//        return id != 1;
//    }
    public boolean insertItemData(String item_name, String item_weight, String item_inventory, String item_description ){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item_name", item_name);
        values.put("item_weight", item_weight);
        values.put("item_inventory", item_inventory);
        values.put("item_description", item_description);

        long result = db.insert("item", null, values);
        if(result == -1){
            return false;
        }else{
            return true;
        }
    }
    //___________________read/get data_____________________

    public Cursor getAllItems(){
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + item_table.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        return cursor;


    }
    public List<Item> getItem(String item_name) {
        List<Item> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + item_table.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setItemName(cursor.getString(0));
                item.setItemWeight(cursor.getString(1));
                item.setItemInventory(cursor.getString(2));
                item.setItemDescription(cursor.getString(3));
                items.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;

    }
//    public List<Item> getItem(ItemSortOrder order){
//        List<Item> items = new ArrayList<>();
//        SQLiteDatabase db = this.getReadableDatabase();
//
//        String orderBy;
//        switch (order) {
//            case ALPHABETIC:
//                orderBy = item_table.ID + " collate nocase";
//                break;
//            default:
//                orderBy = item_table.ITEM_NAME + " asc";
//                break;
//        }
//
//        String sql = "select * from " + item_table.TABLE + " order by " + orderBy;
//        Cursor cursor = db.rawQuery(sql, null);
//        if(cursor.moveToFirst()){
//            //this is setting up a new array for our new array of list
//            do{
//                Item item = new Item();
//                item.setItemName(cursor.getString(0));
//                item.setItemWeight(cursor.getString(1));
//                item.setItemInventory(cursor.getString(2));
//                item.setItemDescription((cursor.getString(3)));
//                items.add(item);
//            }while(cursor.moveToNext());
//        }
//        cursor.close();
//        return items;
//    }
//    public boolean getItem(String item_name, String item_weight, String item_inventory, String item_description){
//      SQLiteDatabase db = this.getReadableDatabase();
//      String sql = "SELECT * FROM " + item_table.TABLE +" WHERE " +
//
//
//    }


    //___________________update data_____________________
    public Boolean updateItem(String item_name, String item_inventory){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("item_name", item_name);
        contentValues.put("item_inventory", item_inventory);
        Cursor cursor = db.rawQuery("SELECT * FROM " +  item_table.TABLE + " where item_name = ? AND item_inventory = ?", new String[]{item_name, item_inventory});
        if(cursor.getCount() > 0) {
            long result = db.update("item", contentValues, "item_name = ?", new String[]{item_name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
            }else{
            return false;
        }
    };
    //___________________Delete data_____________________
    public Boolean deleteItem(String item_name){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM item_name WHERE item_name =?", new String[]{item_name});
        if(cursor.getCount()>0){
            long result = db.delete("item", "item_name = ?", new String[]{item_name});
            if(result == -1){
                return false;
            }else{
                return true;
            }
        }else{
            return false;
        }



//        db.delete(item_table.TABLE, item_table.ID + " = " + itemId, null);
    }
    public boolean checkItemExists(String item_name){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor newCursor = db.rawQuery("SELECT * FROM item WHERE item_name = ?", new String[] {item_name});
        if(newCursor.getCount()>0){
            return true;
        }else{
            return false;
        }
    }

    public boolean checkUsername(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM user WHERE username = ?", new String[] {username});
        if(cursor.getCount()>0){
            return true;
        }else{
            return false;
        }
    }
    public boolean checkUsernamePassword(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM user WHERE username = ? AND password = ?", new String[] {username, password});
        if(cursor.getCount()>0){
            return true;
        }else{
            return false;
        }
    }

}

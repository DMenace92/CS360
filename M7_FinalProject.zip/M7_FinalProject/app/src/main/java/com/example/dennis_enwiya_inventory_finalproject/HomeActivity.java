package com.example.dennis_enwiya_inventory_finalproject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.service.controls.actions.FloatAction;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;



import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class HomeActivity extends AppCompatActivity {

    DBHelper DB;
    //List <Item> ItemList;
    TextView itemNameDisplay, itemWeightDisplay,itemInventoryDisplay, itemDescriptionDisplay;

    Button promptButton;
    RecyclerView mRecyclerView;
    FloatingActionButton fab;
    TextView promptMessage ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_page_layout);
        itemNameDisplay = (TextView)findViewById(R.id.itemNameDisplay);
        itemWeightDisplay = (TextView)findViewById(R.id.itemWeightDisplay);
        itemInventoryDisplay = (TextView) findViewById(R.id.itemInventoryDisplay);
        itemDescriptionDisplay = (TextView)findViewById(R.id.itemDescriptionDisplay);
        DB = new DBHelper(this);
        Cursor results = DB.getAllItems();
      // Cursor results = DB.getAllItems();
       results.moveToFirst();

       System.out.println(results);
//


//        DB = DBHelper.getInstance(getApplicationContext());
//        RecyclerView.LayoutManager gridLayoutManager =
//                new GridLayoutManager(getApplicationContext(), 2);
//        mRecyclerView.setLayoutManager(gridLayoutManager);

        promptButton = (Button)findViewById(R.id.promptButton);
//        floatButton = (Button)findViewById(R.id.floatButton);
        fab = (FloatingActionButton)findViewById(R.id.floatButton);
        StringBuffer buffer = new StringBuffer();
        while(results.moveToNext()){
            buffer.append("item name: " +results.getString(1)+"\n");
            buffer.append("item weight: " +results.getString(2)+"\n");
            buffer.append("item Inventory" +results.getString(3)+"\n");
            buffer.append("item description" +results.getString(4)+"\n\n");
                    itemNameDisplay.setText(results.getString(1));
                    itemWeightDisplay.setText(results.getString(2));
                    itemInventoryDisplay.setText(results.getString(3));
                    itemDescriptionDisplay.setText(results.getString(4));

        }
        promptButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                LayoutInflater layoutInflater = LayoutInflater.from(HomeActivity.this);
                View promptView = layoutInflater.inflate(R.layout.prompt, null);
                AlertDialog.Builder alertdialog = new AlertDialog.Builder(HomeActivity.this);
                alertdialog.setView(promptView);
                TextView promptMessage = (TextView)promptView.findViewById(R.id.notifyPrompt);
                alertdialog.setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialog, int which){
                                String s = promptMessage.getText().toString();
                                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT);
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                alertdialog.create();
                alertdialog.show();
            }



        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, ItemHandler.class);
                startActivity(intent);
            }
        });
    }
}

package com.example.dennis_enwiya_inventory_finalproject;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    EditText username, password, firstname, lastname, email;
    Button signUpButton;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_page);
        username = (EditText) findViewById(R.id.regUsername);
        password = (EditText) findViewById(R.id.regPassword);
        firstname = (EditText) findViewById(R.id.regFirstname);
        lastname = (EditText) findViewById(R.id.regLastname);
        email = (EditText) findViewById(R.id.regEmail);
        signUpButton = (Button) findViewById(R.id.signUpButton);
        DB = new DBHelper(this);

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String fName= firstname.getText().toString();
                String lName = lastname.getText().toString();
                String el = email.getText().toString();


                if(user.equals("")|| pass.equals("")){
                    Toast.makeText(RegisterActivity.this, "Please enter all Fields", Toast.LENGTH_SHORT).show();
                }else{
                    Boolean checkUser = DB.checkUsername(user);
                    if(checkUser == false){
                        Boolean insert = DB.insertUserData(user,pass,fName,lName,el);
                        if(insert == true){
                            Toast.makeText(RegisterActivity.this, "Registered success", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(RegisterActivity.this,HomeActivity.class);
                            startActivity(intent);
                        }else{
                            Toast.makeText(RegisterActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(RegisterActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }

}
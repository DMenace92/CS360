package com.example.dennis_enwiya_inventory_finalproject;

public class Item {
    private long mId;
    private String mItemName;
    private String mItemWeight;
    private String mItemInventory;
    private String mItemDescription ;


    public long getId(){
        return mId;
    }
    public void setId(long id){
        mId = id;
    }

    public String getItemName(){
        return mItemName;
    }

    public String setItemName(String itemName){
        return this.mItemName = itemName;
    }

    public String getItemWeight(){
        return mItemWeight;
    }

    public String setItemWeight(String itemWeight){
        return this.mItemWeight = itemWeight;
    }

    public String getItemInventory(){
        return mItemInventory;
    }

    public String setItemInventory(String mItemInventory){
        return this.mItemInventory = mItemInventory;
    }

    public String getItemDescription(){
        return mItemDescription;
    }

    public String setItemDescription(String mItemDescription){
        return this.mItemDescription = mItemDescription;
    }


}

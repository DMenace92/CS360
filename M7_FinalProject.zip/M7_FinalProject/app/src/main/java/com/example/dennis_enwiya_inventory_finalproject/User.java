package com.example.dennis_enwiya_inventory_finalproject;

public class User {
    private long mId;
    private String mUsername;
    private String mPassword;
    private String mFirstname;
    private String mLastname;
    private String mEmail;
    private String mNotify;

    public long getId(){
        return mId;
    }
    public void setId(long id){
        mId = id;
    }

    public String getUsername(){
        return mUsername;
    }

    public String setUsername(String username){
      return this.mUsername = username;
    }

    public String getPassword(){
        return mPassword;
    }

    public String setPassword(String password){
        return this.mPassword = password;
    }

    public String getFirstname(){
        return mFirstname;
    }

    public String setFirstname(String firstname){
        return this.mFirstname = firstname;
    }

    public String getLastname(){
        return mLastname;
    }

    public String setLastname(String lastname){
        return this.mLastname = lastname;
    }

    public String getEmail(){
        return mEmail;
    }

    public String setEmail(String email){
        return this.mEmail = email;
    }

}

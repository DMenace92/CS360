package com.example.dennis_enwiya_inventory_finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class ItemHandler extends AppCompatActivity {

    EditText createItemName, createItemWeight, createItemInventory,  createItemDescription;
    Button cancelButton, createItemButton, updateButton, deleteButton;

    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_modifier_layout);
        cancelButton = (Button) findViewById(R.id.cancelButton);
        createItemName = (EditText) findViewById(R.id.itemName);
        createItemWeight = (EditText) findViewById(R.id.itemWeight);
        createItemInventory = (EditText) findViewById(R.id.itemInventory);
        createItemDescription = (EditText) findViewById(R.id.itemDescription);
        createItemButton = (Button) findViewById(R.id.createItemButton);
        updateButton = (Button) findViewById(R.id.updateButton);
        deleteButton = (Button) findViewById(R.id.deleteButton);
      //  mInventoryDb = DBHelper.getInstance(getApplicationContext());
        DB = new DBHelper(this);

        createItemButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String ina = createItemName.getText().toString();
                String inw = createItemWeight.getText().toString();
                String ii = createItemInventory.getText().toString();
                String ide =  createItemDescription.getText().toString();

                if(ina.equals("")){
                    Toast.makeText(ItemHandler.this, "Need to complete all the required fields", Toast.LENGTH_SHORT).show();
                }else{
                    Boolean checkItem = DB.checkItemExists(ina);
                    if(checkItem == false){
                        Boolean insert = DB.insertItemData(ina, inw, ii, ide);
                        if(insert == true){
                            Toast.makeText(ItemHandler.this, "Item was Successfully create!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(ItemHandler.this, HomeActivity.class);
                            startActivity(intent);
                        }else{
                            Toast.makeText(ItemHandler.this, "Item create Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(ItemHandler.this, "Item already exists", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
        updateButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                //to update wee will find by name then enter the new inventory number.
                String ina = createItemName.getText().toString();
                String ii = createItemInventory.getText().toString();
                if(ina.equals("")|| ii.equals("")){
                    Toast.makeText(ItemHandler.this, "Please enter Item Name and new item Quantity", Toast.LENGTH_SHORT).show();
                }else{
                    Boolean checkItem = DB.checkItemExists(ina);
                    if(checkItem == false){
                        Boolean update = DB.updateItem(ina,ii);
                        Toast.makeText(ItemHandler.this, "Item Dose Not exist !", Toast.LENGTH_SHORT).show();
                        if(update == true){
                            Toast.makeText(ItemHandler.this, "Item was Successfully updated!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(ItemHandler.this, HomeActivity.class);
                            startActivity(intent);

                        }else{
                            Toast.makeText(ItemHandler.this, "Item Update Failed", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(ItemHandler.this, "Item Update Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        deleteButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View dView){
                String ina = createItemName.getText().toString();
                if(ina.equals("")){
                    Toast.makeText(ItemHandler.this, "Please enter Item Name", Toast.LENGTH_SHORT).show();
                }

            }

        });
        cancelButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(ItemHandler.this, HomeActivity.class);
                startActivity(intent);
            }
        });
    }
}
